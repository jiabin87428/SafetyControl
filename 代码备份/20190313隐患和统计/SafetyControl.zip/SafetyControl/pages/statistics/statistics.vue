<template>
	<view class="part2">
		<view class="titleView_pc">
			<text class="titleText_pc">数据统计</text>
		</view>
		<view class="menuBlockView">
		  <view class='blockView'>
		    <view class='subView'>
		      <text class='numText'>1005</text>
		    </view>
		    <view class='subView'>
		      <text class='nameText'>待整改</text>
		    </view>
		  </view>
		  <view class='blockView'>
		    <view class='subView'>
		      <text class='numText'>1005</text>
		    </view>
		    <view class='subView'>
		      <text class='nameText'>已整改</text>
		    </view>
		  </view>
		  <view class='blockView'>
		    <view class='subView'>
		      <text class='numText'>1005</text>
		    </view>
		    <view class='subView'>
		      <text class='nameText'>隐患总数</text>
		    </view>
		  </view>
		  <view class='blockView'>
		    <view class='subView'>
		      <text class='numText'>1005</text>
		    </view>
		    <view class='subView'>
		      <text class='nameText'>今日检查(次)</text>
		    </view>
		  </view>
		  <view class='blockView'>
		    <view class='subView'>
		      <text class='numText'>1005</text>
		    </view>
		    <view class='subView'>
		      <text class='nameText'>检查记录</text>
		    </view>
		  </view>
		  <view class='blockView'>
		    <view class='subView'>
		      <text class='numText'>1005</text>
		    </view>
		    <view class='subView'>
		      <text class='nameText'>检查模板</text>
		    </view>
		  </view>
		  <view class='blockView'>
		    <view class='subView'>
		      <text class='numText'>1005</text>
		    </view>
		    <view class='subView'>
		      <text class='nameText'>今日作业</text>
		    </view>
		  </view>
		  <view class='blockView'>
		    <view class='subView'>
		      <text class='numText'>1005</text>
		    </view>
		    <view class='subView'>
		      <text class='nameText'>明日作业</text>
		    </view>
		  </view>
		  <view class='blockView'>
		    <view class='subView'>
		      <text class='numText'>1005</text>
		    </view>
		    <view class='subView'>
		      <text class='nameText'>作业总数</text>
		    </view>
		  </view>
		  <view class='blockView'>
		    <view class='subView'>
		      <text class='numText'>1005</text>
		    </view>
		    <view class='subView'>
		      <text class='nameText'>外施工单位</text>
		    </view>
		  </view>
		  <view class='blockView'>
		    <view class='subView'>
		      <text class='numText'>1005</text>
		    </view>
		    <view class='subView'>
		      <text class='nameText'>施工项目</text>
		    </view>
		  </view>
		  <view class='blockView'>
		    <view class='subView'>
		      <text class='numText'>1005</text>
		    </view>
		    <view class='subView'>
		      <text class='nameText'>应急演练(次)</text>
		    </view>
		  </view>
		  <view class='blockView'>
		    <view class='subView'>
		      <text class='numText'>1005</text>
		    </view>
		    <view class='subView'>
		      <text class='nameText'>变更</text>
		    </view>
		  </view>
		  <view class='blockView'>
		    <view class='subView'>
		      <text class='numText'>1005</text>
		    </view>
		    <view class='subView'>
		      <text class='nameText'>设备检查(次)</text>
		    </view>
		  </view>
		  <view class='blockView'>
		    <view class='subView'>
		      <text class='numText'>1005</text>
		    </view>
		    <view class='subView'>
		      <text class='nameText'>设备检测(次)</text>
		    </view>
		  </view>
		  <view class='blockView'>
		    <view class='subView'>
		      <text class='numText'>1005</text>
		    </view>
		    <view class='subView'>
		      <text class='nameText'>培训记录</text>
		    </view>
		  </view>
		  <view class='blockView'>
		    <view class='subView'>
		      <text class='numText'>1005</text>
		    </view>
		    <view class='subView'>
		      <text class='nameText'>练习(次)</text>
		    </view>
		  </view>
		  <view class='blockView'>
		    <view class='subView'>
		      <text class='numText'>1005</text>
		    </view>
		    <view class='subView'>
		      <text class='nameText'>培训教材</text>
		    </view>
		  </view>
		  <view class='blockView'>
		    <view class='subView'>
		      <text class='numText'>1005</text>
		    </view>
		    <view class='subView'>
		      <text class='nameText'>题库数</text>
		    </view>
		  </view>
		  <view class='blockView'>
		    <view class='subView'>
		      <text class='numText'>1005</text>
		    </view>
		    <view class='subView'>
		      <text class='nameText'>考试(次)</text>
		    </view>
		  </view>
		  <view class='blockView'>
		    <view class='subView'>
		      <text class='numText'>1005</text>
		    </view>
		    <view class='subView'>
		      <text class='nameText'>法规数</text>
		    </view>
		  </view>
		  <view class='blockView'>
		    <view class='subView'>
		      <text class='numText'>1005</text>
		    </view>
		    <view class='subView'>
		      <text class='nameText'>常见隐患知识库</text>
		    </view>
		  </view>
		  <view class='blockView'>
		    <view class='subView'>
		      <text class='numText'>1005</text>
		    </view>
		    <view class='subView'>
		      <text class='nameText'>安全例会(次)</text>
		    </view>
		  </view>
		  <view class='blockView'>
		    <view class='subView'>
		      <text class='numText'>1005</text>
		    </view>
		    <view class='subView'>
		      <text class='nameText'>MSDS</text>
		    </view>
		  </view>
		  <view class='blockView'>
		    <view class='subView'>
		      <text class='numText'>1005</text>
		    </view>
		    <view class='subView'>
		      <text class='nameText'>应急物资</text>
		    </view>
		  </view>
		  <view class='blockView'>
		    <view class='subView'>
		      <text class='numText'>1005</text>
		    </view>
		    <view class='subView'>
		      <text class='nameText'>设备</text>
		    </view>
		  </view>
		  <view class='blockView'>
		    <view class='subView'>
		      <text class='numText'>1005</text>
		    </view>
		    <view class='subView'>
		      <text class='nameText'>行动</text>
		    </view>
		  </view>
		  <view class='blockView'>
		    <view class='subView'>
		      <text class='numText'>1005</text>
		    </view>
		    <view class='subView'>
		      <text class='nameText'>系统用户</text>
		    </view>
		  </view>
		  <view class='blockView'>
		    <view class='subView'>
		      <text class='numText'>1005</text>
		    </view>
		    <view class='subView'>
		      <text class='nameText'>重大危险源</text>
		    </view>
		  </view>
		  <view class='blockView'>
		  </view>
		</view>
	</view>
</template>

<script>
</script>

<style>
	.titleView_pc {
		display: flex;
		flex-direction: row;
		align-items: center;
		width: 100%;
		height: 80upx;
		background-color: #FFFFFF;
		border-bottom-width: 1px;
		border-bottom-style: solid;
		border-bottom-color: #F1F1F1;
	}
	.titleText_pc {
		margin-left: 30upx;
		color: #666666;
		width: 100%;
		text-align: left;
		font-size: 32upx;
	}
	/* 菜单按钮 */
	.menuBlockView {
	  width: 100%;
	  background-color: #FFFFFF;
	  display: flex;
	  flex-wrap: wrap;
	  flex-direction: row;
	  justify-content: space-around;
	  padding-bottom: 30upx;
	}
	.blockView {
	  display:flex;
	  flex-direction:column;
	  width: 30%;
	  margin-top: 50px;
	  align-items:center;/*垂直居中*/
	}
	.subView {
	  display:flex;
	  flex-direction:column;
	  width: 100%;
	  margin-top: 10px;
	  align-items:center;/*垂直居中*/
	}
	.numText {
		width: 100%;
		font-size: 40upx;
		color: #232323;
		text-align: center;
	}
	.nameText {
		width: 100%;
		font-size: 28upx;
		color: #898989;
		text-align: center;
	}
</style>
